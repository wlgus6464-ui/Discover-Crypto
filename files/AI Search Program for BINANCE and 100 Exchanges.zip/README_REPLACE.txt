Replace this file with the real Trader's Notes archive.
Keep the filename: Traders_Notes.zip
